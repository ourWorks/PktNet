# # 七、灰质、白质、脑脊液的分割##############################################################################################
imgList = [os.path.join(MNI_BRAIN_PATH,item) for item in os.listdir(MNI_BRAIN_PATH) if item.endswith("_mniBrain_removeEdge.nii.gz")]   # 这里需要选好某个尺寸的MNI大脑文件
# for item in imgDictList:
def oneFast(idx, fastItem):
    # 只需要处理后的brain
    segBaseName = os.path.basename(fastItem).replace(".nii.gz","")
    segBaseNameAbsPath = os.path.join(SEG_PATH, segBaseName)
    fast_cmd = ["fast","-s",1,"-t", 2, "-n", 3, "-H", 0.1, "-I", 4, "-l", 20.0, "-o", segBaseNameAbsPath, fastItem]
    include_num_cmd = [str(item) for item in fast_cmd]

    pool_sema.acquire()  # 线程准备开始，加锁，限制线程数
    print('assignment %s start,item %s' % (idx, segBaseNameAbsPath))
    if not os.path.exists(f"{segBaseNameAbsPath}_seg.nii.gz"):
        subprocess.run(include_num_cmd)
    print('assignment %s end,item %s' % (idx, segBaseNameAbsPath))
    pool_sema.release()  # 线程结束，解锁
    
threads = []
imgList.sort()
for idx,item in enumerate(imgList, start=1):
    thread = threading.Thread(target=oneFast, args=(idx, item))
    threads.append(thread)
    thread.start()

# 主线程等待所有子线程执行完毕
for thread in threads:
    thread.join() #【必须加上】
